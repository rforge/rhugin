uncompile <- function(domain)
  invisible(.Call(RHugin_domain_uncompile, domain))


