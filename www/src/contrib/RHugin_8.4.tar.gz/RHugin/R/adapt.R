adapt <- function(domain)
  invisible(.Call(RHugin_domain_adapt, domain))


