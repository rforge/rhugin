compress <- function(domain)
  .Call(RHugin_domain_compress, domain)


