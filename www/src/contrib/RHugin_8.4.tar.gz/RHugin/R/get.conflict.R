get.conflict <- function(domain)
  .Call(RHugin_domain_get_conflict, domain)


