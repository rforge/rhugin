reset <- function(domain)
  invisible(.Call(RHugin_domain_reset_inference_engine, domain))


