get.approximation.constant <- function(domain)
  .Call(RHugin_domain_get_approximation_constant, domain)


