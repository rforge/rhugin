RHUGIN.RESERVED <- c("Freq", "Prob", "Value", "Cost", "Utility",
                     "Counts", "Lambda", "Expression")


RHUGIN.SUBTYPES <- c("labeled", "boolean", "numbered", "interval")


