initialize.domain <- function(domain)
  invisible(.Call(RHugin_domain_initialize, domain))


