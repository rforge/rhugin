### R code from vignette source 'RHugin.Snw'

###################################################
### code chunk number 1: RHugin.Snw:82-83
###################################################
library(RHugin)


###################################################
### code chunk number 2: RHugin.Snw:93-94 (eval = FALSE)
###################################################
## help(hugin.domain)


###################################################
### code chunk number 3: RHugin.Snw:99-100 (eval = FALSE)
###################################################
## ls("package:RHugin")


###################################################
### code chunk number 4: RHugin.Snw:125-126
###################################################
apple <- hugin.domain()


###################################################
### code chunk number 5: RHugin.Snw:135-138
###################################################
add.node(apple, "Sick", states = c("yes", "no"))
add.node(apple, "Dry", states = c("yes", "no"))
add.node(apple, "Loses", states = c("yes", "no"))


###################################################
### code chunk number 6: RHugin.Snw:145-147
###################################################
add.edge(apple, "Loses", "Dry")
add.edge(apple, "Loses", "Sick")


###################################################
### code chunk number 7: RHugin.Snw:152-153 (eval = FALSE)
###################################################
## plot(apple)


###################################################
### code chunk number 8: RHugin.Snw:162-163
###################################################
plot(apple)


###################################################
### code chunk number 9: RHugin.Snw:206-207
###################################################
sick.table <- get.table(apple, "Sick")


###################################################
### code chunk number 10: RHugin.Snw:212-213
###################################################
sick.table


###################################################
### code chunk number 11: RHugin.Snw:218-220
###################################################
sick.table[["Freq"]] <- c(0.1, 0.9)
set.table(apple, "Sick", sick.table)


###################################################
### code chunk number 12: RHugin.Snw:225-226
###################################################
get.table(apple, "Sick")


###################################################
### code chunk number 13: RHugin.Snw:231-234
###################################################
dry.table <- get.table(apple, "Dry")
dry.table[["Freq"]] <- c(0.1, 0.9)
set.table(apple, "Dry", dry.table)


###################################################
### code chunk number 14: RHugin.Snw:239-241
###################################################
loses.table <- get.table(apple, "Loses")
loses.table


###################################################
### code chunk number 15: RHugin.Snw:246-248
###################################################
loses.table[["Freq"]] <- c(0.95, 0.05, 0.90, 0.10, 0.85, 0.15, 0.02, 0.98)
set.table(apple, "Loses", loses.table)


###################################################
### code chunk number 16: RHugin.Snw:253-254
###################################################
get.table(apple, "Loses", class = "ftable")


###################################################
### code chunk number 17: RHugin.Snw:261-262 (eval = FALSE)
###################################################
## write.rhd(apple, file = "apple.net", type = "net")


###################################################
### code chunk number 18: RHugin.Snw:267-268 (eval = FALSE)
###################################################
## apple.copy <- read.rhd("apple.net")


###################################################
### code chunk number 19: RHugin.Snw:276-277
###################################################
compile(apple)


###################################################
### code chunk number 20: RHugin.Snw:282-283
###################################################
set.finding(apple, "Loses", "yes")


###################################################
### code chunk number 21: RHugin.Snw:288-289
###################################################
propagate(apple)


###################################################
### code chunk number 22: RHugin.Snw:294-296
###################################################
get.belief(apple, "Sick")
get.belief(apple, "Dry")


###################################################
### code chunk number 23: RHugin.Snw:391-393
###################################################
params <- get.sensitivity(apple, "Sick", "yes", Dry = "yes")
params


###################################################
### code chunk number 24: RHugin.Snw:398-400
###################################################
sensitivity.func <- function(x, alpha, beta, gamma, delta)
  (alpha * x + beta) / (gamma * x + delta)


###################################################
### code chunk number 25: RHugin.Snw:405-408 (eval = FALSE)
###################################################
## x <- seq(0.025, 0.2, by = 0.001)
## y <- sensitivity.func(x, params[1], params[2], params[3], params[4])
## plot(x, y)


###################################################
### code chunk number 26: RHugin.Snw:411-421
###################################################
pdf(file = "sweavedImages/sensitivity.pdf", height = 4.5, width = 6)
x <- seq(0.025, 0.2, by = 0.001)
y <- sensitivity.func(x, params[1], params[2], params[3], params[4])
plot(x, y, type = "l", ylim = c(0,1), xlab = "P(Dry = \"yes\")",
     ylab = "P(Sick = \"yes\" | Loses = \"yes\")", axes = FALSE)
axis(1)
axis(2, las = 1)
box()
points(0.1, get.belief(apple, "Sick")["yes"], pch = 16)
dev.off()


